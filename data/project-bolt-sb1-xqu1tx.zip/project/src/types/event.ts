export interface Event {
  id: string;
  name: string;
  location: string;
  startTime: string;
  endTime: string;
  description: string;
  cost: number;
}

export interface ProcessedEventData {
  events: Event[];
  lastUpdated: string;
  source: string;
}