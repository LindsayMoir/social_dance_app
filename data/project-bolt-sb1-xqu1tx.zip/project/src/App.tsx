import React, { useState } from 'react';
import { CalendarGrid } from './components/Calendar/CalendarGrid';
import { EventReport } from './components/Reports/EventReport';
import { ProcessedEventData } from './types/event';
import { processEventData } from './utils/eventProcessor';

// Sample data for demonstration
const sampleData = {
  events: [
    {
      id: '1',
      name: 'Tech Conference 2024',
      location: 'Convention Center',
      startTime: '2024-03-20T09:00:00',
      endTime: '2024-03-20T17:00:00',
      description: 'Annual technology conference featuring the latest innovations',
      cost: 299.99
    },
    {
      id: '2',
      name: 'Workshop: AI Basics',
      location: 'Innovation Hub',
      startTime: '2024-03-22T14:00:00',
      endTime: '2024-03-22T16:00:00',
      description: 'Introduction to artificial intelligence concepts',
      cost: 49.99
    }
  ],
  source: 'Sample Data'
};

function App() {
  const [eventData] = useState<ProcessedEventData>(processEventData(sampleData));

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-6xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold text-gray-900 text-center mb-8">
          Event Calendar & Reports
        </h1>
        
        <div className="grid md:grid-cols-2 gap-8">
          <CalendarGrid events={eventData.events} />
          <EventReport events={eventData.events} />
        </div>
        
        <div className="text-center text-sm text-gray-500">
          Last updated: {new Date(eventData.lastUpdated).toLocaleString()}
        </div>
      </div>
    </div>
  );
}

export default App;