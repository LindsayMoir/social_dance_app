import { ProcessedEventData, Event } from '../types/event';

export const processEventData = (jsonData: any): ProcessedEventData => {
  const events: Event[] = jsonData.events.map((event: any) => ({
    id: event.id,
    name: event.name,
    location: event.location,
    startTime: event.startTime,
    endTime: event.endTime,
    description: event.description,
    cost: parseFloat(event.cost) || 0
  }));

  return {
    events,
    lastUpdated: new Date().toISOString(),
    source: jsonData.source || 'Unknown'
  };
};