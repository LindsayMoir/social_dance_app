import React from 'react';
import { format } from 'date-fns';
import { Event } from '../../types/event';
import { Calendar } from 'lucide-react';

interface CalendarGridProps {
  events: Event[];
}

export const CalendarGrid: React.FC<CalendarGridProps> = ({ events }) => {
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Event Calendar
        </h2>
      </div>
      <div className="divide-y">
        {events.map((event) => (
          <div key={event.id} className="p-4 hover:bg-gray-50 transition-colors">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-medium text-gray-900">{event.name}</h3>
                <p className="text-sm text-gray-600">{event.location}</p>
              </div>
              <span className="text-sm font-medium text-green-600">
                ${event.cost.toFixed(2)}
              </span>
            </div>
            <div className="mt-2">
              <p className="text-sm text-gray-500">
                {format(new Date(event.startTime), 'PPp')} - 
                {format(new Date(event.endTime), 'p')}
              </p>
              <p className="mt-1 text-sm text-gray-600">{event.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};