import React from 'react';
import { Event } from '../../types/event';
import { FileText } from 'lucide-react';

interface EventReportProps {
  events: Event[];
}

export const EventReport: React.FC<EventReportProps> = ({ events }) => {
  const totalEvents = events.length;
  const totalCost = events.reduce((sum, event) => sum + event.cost, 0);

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center gap-2 mb-4">
        <FileText className="w-5 h-5 text-blue-600" />
        <h2 className="text-xl font-semibold text-gray-800">Event Summary Report</h2>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm text-blue-600">Total Events</p>
          <p className="text-2xl font-bold text-blue-700">{totalEvents}</p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-sm text-green-600">Total Cost</p>
          <p className="text-2xl font-bold text-green-700">${totalCost.toFixed(2)}</p>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-medium text-gray-800">Event Distribution</h3>
        <div className="space-y-2">
          {events.map((event) => (
            <div key={event.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
              <span className="text-sm text-gray-600">{event.name}</span>
              <span className="text-sm font-medium text-gray-800">${event.cost.toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};